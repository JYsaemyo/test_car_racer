import pygame
import random

# 초기화
pygame.init()
pygame.mixer.init()  # 믹서 초기화

# 화면 크기 설정
WIDTH, HEIGHT = 600, 800
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("자동차 게임")

# 색상 정의
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# 배경 음악 로드 및 재생
pygame.mixer.music.load("background_music.mp3")  # 음악 파일 로드
pygame.mixer.music.play(-1)  # 음악 반복 재생 (-1은 무한 반복을 의미)

# 자동차 클래스
class Car:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = 50
        self.height = 100
        # 새 이미지 불러오기 및 크기 조정
        self.image = pygame.image.load("player_car.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.width, self.height))

    def move(self, dy):
        self.y += dy

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))

# 상대방 자동차 클래스
class OpponentCar:
    def __init__(self, x, y, speed):
        self.x = x
        self.y = y
        self.speed = speed
        self.width = 50
        self.height = 100
        # 새 이미지 불러오기 및 크기 조정
        self.image = pygame.image.load("opponent_car.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.width, self.height))

    def move(self):
        self.y += self.speed

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))

def main():
    run = True
    clock = pygame.time.Clock()
    player_car = Car(WIDTH // 2 - 25, HEIGHT - 100 - 20)
    opponents = []
    opponent_gap = 20
    opponent_timer = 0

    while run:
        # 게임 속도 조절
        clock.tick(30)

        # 이벤트 처리
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        # 플레이어 자동차 이동
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_car.x > 0:
            player_car.x -= 5
        if keys[pygame.K_RIGHT] and player_car.x < WIDTH - player_car.width:
            player_car.x += 5

        # 상대방 자동차 생성 및 이동
        if opponent_timer == 0 or opponent_timer >= opponent_gap:
            opponent_x = random.randrange(0, WIDTH - 50)
            opponent_speed = random.randint(8, 15)  # 무작위 속도 설정
            opponents.append(OpponentCar(opponent_x, -20, opponent_speed))
            opponent_timer = 1
        else:
            opponent_timer += 1

        for opponent in opponents:
            opponent.move()
            if opponent.y > HEIGHT:
                opponents.remove(opponent)

        # 충돌 검사
        for opponent in opponents:
            if opponent.y + opponent.height > player_car.y and player_car.x + player_car.width > opponent.x and player_car.x < opponent.x + opponent.width:
                run = False

        # 화면 업데이트
        WIN.fill((255, 255, 255))
        player_car.draw(WIN)
        for opponent in opponents:
            opponent.draw(WIN)
        pygame.display.update()

    pygame.quit()

if __name__ == "__main__":
    main()
